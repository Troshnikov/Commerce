<?PHP

require_once('controllers/GlobalController.php');

class ProductsTypeControllerAdmin extends GlobalController
{
	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}
	
	function fetch()
	{
		if (!(isset($_SESSION['admin']) && $_SESSION['admin']=='admin'))
			header("Location: http://".$_SERVER['SERVER_NAME']."/rbt/");
		
		$edit_module = $this->furl->get_module_by_name('ProductsTypeControllerAdmin');
		$main_module =  $this->furl->get_module_by_name('ProductsTypesControllerAdmin');
        //$type_frontend_module = $this->furl->get_module_by_name('GroupController');
		$this->design->assign('main_module', $main_module);
        //$this->design->assign('group_frontend_module', $group_frontend_module);

		if ($this->request->method('post'))
		{
			$type = new stdClass();
			$type->id = $this->request->post('id', 'integer');
			$type->name_singular = $this->request->post('name_singular');
			$type->name_plural = $this->request->post('name_plural');
			
			$type->visible = $this->request->post('visible', 'boolean');
			$type->css_class = $this->request->post('css_class');
			
			$close_after_save = $this->request->post('close_after_save', 'integer');
			$add_after_save = $this->request->post('add_after_save', 'integer');

			if(empty($type->id))
			{
				$type->id = $this->products_types->add_type($type);
				$this->design->assign('message_success', 'added');
			}
			else
			{
				$this->products_types->update_type($type->id, $type);
				$this->design->assign('message_success', 'updated');
			}
			
			$type = $this->products_types->get_type(intval($type->id));
			
			$return_page = $this->request->post('return_page');
			
			if ($close_after_save && $main_module)
				header("Location: ".$this->config->root_url.$main_module->url.($return_page>1?'?page='.$return_page:''));
			
			if ($add_after_save)
				header("Location: ".$this->config->root_url.$edit_module->url.($return_page>1?'?page='.$return_page:''));
		}
		else
			{
				$id = 0;
				$mode = "";
				$response['success'] = false;
				$json_answer = false;
				foreach($this->params_arr as $p=>$v)
				{
					switch ($p)
					{
						case "id":
							if (is_numeric($v))
								$id = intval($v);
							else
								$id = strval($v);
							break;
						case "mode":
							$mode = strval($v);
							break;
						case "ajax":
							$json_answer = true;
							unset($this->params_arr[$p]);
							break;
						case "page":
							$this->design->assign('page', intval($v));
							unset($this->params_arr[$p]);
							break;
					}
				}
				
				if (!empty($id))
					$type = $this->products_types->get_type($id);
				
				if (!empty($mode) && ((isset($type) && !empty($type)) || !is_numeric($id)))
					switch($mode){
						case "delete":
							$this->products_types->delete_type($id);
							$response['success'] = true;
							break;
						case "toggle":
							$this->products_types->update_type($id, array('visible'=>1-$type->visible));
							$response['success'] = true;
							break;
                        case "toggle_popular":
							$this->products_types->update_type($id, array('is_popular'=>1-$type->is_popular));
							$response['success'] = true;
							break;
					}
				
				if ($json_answer)
				{
					header("Content-type: application/json; charset=UTF-8");
					header("Cache-Control: must-revalidate");
					header("Pragma: no-cache");
					header("Expires: -1");
					if ($mode == "get_tags")
						print json_encode($response['data']);
					else	
						print json_encode($response);
					die();
				}
			}
		if (isset($type))
		{
			$this->design->assign('type', $type);
		}
		else
			$this->design->assign('type', null);
		
		return $this->design->fetch($this->design->getTemplateDir('admin').'products-type.tpl');
	}
}