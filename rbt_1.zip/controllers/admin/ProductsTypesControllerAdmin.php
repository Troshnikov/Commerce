<?PHP

require_once('controllers/GlobalController.php');

class ProductsTypesControllerAdmin extends GlobalController
{
	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}
	
	private function process_menu($item, $parent_id, &$menu)
	{
		if (!array_key_exists($parent_id, $menu))
			$menu[$parent_id] = array();
		$menu[$parent_id][] = intval($item['id']);
		if (isset($item['children']))
			foreach($item['children'] as $i)
				$this->process_menu($i, intval($item['id']), $menu);
	}
	
	function fetch()
	{
		if (!(isset($_SESSION['admin']) && $_SESSION['admin']=='admin'))
			header("Location: http://".$_SERVER['SERVER_NAME']."/rbt/");
		
		$types_filter = array();
		$current_page = 1;
		
		foreach($this->params_arr as $p=>$v)
		{
			switch ($p)
			{
				case "save_positions":
					$menu_items = $this->request->post('menu');
					$menu = array();
					foreach($menu_items as $item)
						$this->process_menu($item, 0, $menu);
					foreach($menu as $parent_id=>$items)
						foreach($items as $position=>$id)
							$this->products_types->update_type($id, array('position'=>$position));

					header("Content-type: application/json; charset=UTF-8");
					header("Cache-Control: must-revalidate");
					header("Pragma: no-cache");
					header("Expires: -1");
					print json_encode(1);
					die();
					break;
				case "page":
					if (!empty($this->params_arr[$p]))
						$current_page = intval($this->params_arr['page']);
					else
						unset($this->params_arr[$p]);
					break;
				case "sort":
					if (!empty($this->params_arr[$p]))
						$types_filter[$p] = $this->params_arr[$p];
					else
						unset($this->params_arr[$p]);
					break;
				case "sort_type":
					if (!empty($this->params_arr[$p]))
					{
						if (!array_key_exists('sort_type', $types_filter))
							$types_filter[$p] = $this->params_arr[$p];
					}
					else
						unset($this->params_arr[$p]);
					break;
			}
		}
		
		/*Зададим сортировку по умолчанию*/
		if (!array_key_exists('sort', $this->params_arr))
		{
			$types_filter['sort'] = 'name';
		}
		
		if (!array_key_exists('sort_type', $this->params_arr))
		{
			$types_filter['sort_type'] = 'asc';
		}
		
		$this->design->assign('current_params', $this->params_arr);
		
		$types_count = $this->products_types->count_types($types_filter);
		
		// Постраничная навигация
		if (array_key_exists('page', $this->params_arr) && $this->params_arr['page'] == 'all')
			$items_per_page = $types_count;
		else
			$items_per_page = $this->settings->brands_num_admin;
		
		$this->design->assign('types_count', $types_count);
		$pages_num = $items_per_page>0 ? ceil($types_count/$items_per_page): 0;
		$this->design->assign('total_pages_num', $pages_num);
		
		// Если страница не задана, то равна 1
		$current_page = max(1, $current_page);
		$current_page = min($current_page, $pages_num);
		$this->design->assign('current_page_num', $current_page);
		
		$types_filter['page'] = $current_page;
		$types_filter['limit'] = $items_per_page;

		$types = $this->products_types->get_types($types_filter);
		foreach($types as $index=>$type)
			$types[$index]->products_count = $this->products->count_products(array('type_id'=>$type->id));

		$this->design->assign('types', $types);
		$this->design->assign('params_arr', $this->params_arr);
		$this->design->assign('edit_module', $this->furl->get_module_by_name('ProductsTypeControllerAdmin'));
		return $this->design->fetch($this->design->getTemplateDir('admin').'products-types.tpl');
	}
}