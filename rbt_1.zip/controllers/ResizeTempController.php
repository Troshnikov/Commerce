<?PHP



require_once('GlobalController.php');

class ResizeTempController extends GlobalController
{	
	private $param_url, $options;

	public function __construct()
	{
		parent::__construct();
	}
	
	public function set_params($url = null, $options = null)
	{
		$this->param_url = $url;
		$this->options = $options;
	}

	/**
	 *
	 * Отображение
	 *
	 */
	function fetch()
	{
		if ($this->param_url[0] == "/")
			$this->param_url = mb_substr($this->param_url, 1, mb_strlen($this->param_url, 'utf-8')-1, 'utf-8');
			
		$arr = explode("/", $this->param_url);
		$keys = array_keys($arr);
		
		/*if (count($arr)<2)
			return false;*/
		
		### Получим объект
		/*$object = reset($arr);
		unset($arr[reset($keys)]);*/

		### Получим имя файла
		$filename = end($arr);
		unset($arr[end($keys)]);
				
		### Извлечем из filename token
		/*$arr = explode("?", $filename);
		if (count($arr) !== 2)
			return false;
		
		$filename = $arr[0];
		$token = $arr[1];

		if(!$this->config->check_token($filename, $token))
			exit('bad token');*/
		
		$resized_filename =  $this->image_temp->resize($filename);
		
		if(is_readable($resized_filename))
		{
			header('Content-type: image');
			print file_get_contents($resized_filename);
		}
	}
}