<?PHP


 
require_once('controllers/GlobalController.php');

class ReviewsController extends GlobalController
{
	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}

	function fetch()
	{
        $filter = array('visible' => 1);
		if ($this->settings->reviews_shop_premoderate)
			$filter['moderated'] = 1;
		
        $current_page = 1;

		if ($this->request->method('post'))
		{
			$review_name = $this->request->post('name');
			$review_short = $this->request->post('short');
			$review_comments = $this->request->post('comments');
			$review_recommended = $this->request->post('recommended');
			$review_rating = $this->request->post('rating', 'integer');
			$review_temp_id = $this->request->post('temp_id');
			
			$review_id = $this->request->post('review_id', 'integer');
			$review_helpful = $this->request->post('helpful', 'integer');
			$review_nothelpful = $this->request->post('nothelpful', 'integer');
			
			$review_claim_type = $this->request->post('claim_type');
			$review_claim_text = $this->request->post('claim_text');
			
			if (isset($review_name) && isset($review_short) && isset($review_comments) && isset($review_rating)){
				
				$review_by_user = false;
				$review_by_session = false;
				
				$is_admin = false;
				
				if (isset($this->user)){
					$review_by_user = $this->reviews->get_shop_rate_by_user_id($this->user->id);
					
					$granted = $this->users->check_permission($this->user->id, "LoginControllerAdmin", "admin");
					if($granted)
						$is_admin = true;
				}
				else
					$review_by_session = $this->reviews->get_shop_rate_by_session_id(session_id());
				
				if ((!$review_by_user && !$review_by_session) || $is_admin)
				{
					$review = new stdClass;
					$review->rating = $review_rating;
					$review->name = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_name);
					$review->short = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_short);
					$review->comments = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_comments);
					$review->recommended = $review_recommended;
					if (isset($this->user))
						$review->user_id = $this->user->id;
					else
						$review->session_id = session_id();
					
					$review->visible = 1;
					
					$review->id = $this->reviews->add_shop_review($review);
					
					$images = $this->image_temp->get_images($review_temp_id);
					if (!empty($images)){
						foreach($images as $i){
							$fname = $this->config->root_dir . '/' . $this->config->original_tempimages_dir . $i->filename;
							$this->image->add_internet_image('shop-reviews', $review->id, uniqid(), $fname);
							$this->image_temp->delete_image($i->temp_id, $i->id);
						}
					}
				}
				else
				{
					$review->rating = $review_rating;
					$review->name = $review_name;
					$review->short = $review_short;
					$review->comments = $review_comments;
					$review->recommended = $review_recommended;
					if ($review_by_user)
						$review->id = $review_by_user->id;
					else
						$review->id = $review_by_session->id;
					
					$review->visible = 1;
					
					$this->reviews->update_shop_review($review->id, $review);
					
					$images = $this->image->get_images('shop-reviews', $review->id);
					foreach($images as $i)
						$this->image->delete_image('shop-reviews', $review->id, $i->id);
					
					$images = $this->image_temp->get_images($review_temp_id);
					if (!empty($images)){
						foreach($images as $i){
							$fname = $this->config->root_dir . '/' . $this->config->original_tempimages_dir . $i->filename;
							$this->image->add_internet_image('shop-reviews', $review->id, uniqid(), $fname);
							$this->image_temp->delete_image($i->temp_id, $i->id);
						}
					}
				}
				
				$this->design->assign('show_message_review_add', true);
				
				/*header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($review->id);
				die();*/
			}
			
			if (!empty($review_id) && (!empty($review_helpful) || !empty($review_nothelpful))){
				$response_by_user = false;
				$response_by_session = false;
				
				if (isset($this->user))
					$response_by_user = $this->reviews->get_shop_review_response_by_user_id($review_id, $this->user->id);
				else
					$response_by_session = $this->reviews->get_shop_review_response_by_session_id($review_id, session_id());
				
				$data = array();
				
				if (!$response_by_user && !$response_by_session)
				{
					$response = new stdClass;
					$response->review_id = $review_id;
					$response->helpful = $review_helpful;
					$response->nothelpful = $review_nothelpful;
					$response->user_id = isset($this->user) ? $this->user->id : NULL;
					$response->session_id = isset($this->user) ? "" : session_id();
					$response->id = $this->reviews->add_shop_response($response);
					
					$review = $this->reviews->get_shop_review($review_id);
					if ($review_helpful)
						$this->reviews->update_shop_review($review_id, array('helpful' => $review->helpful + 1));
					else
						$this->reviews->update_shop_review($review_id, array('nothelpful' => $review->nothelpful + 1));
					
					$data['success'] = true;
					$data['helpful'] = $review_helpful ? $review->helpful + 1 : $review->helpful;
					$data['nothelpful'] = $review_nothelpful ? $review->nothelpful + 1 : $review->nothelpful;
				}
				else
				{
					$data['success'] = false;
					$data['message'] = 'exists';
				}
				
				header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($data);
				die();
			}
			
			if (!empty($review_id) && isset($review_claim_type) && isset($review_claim_text)){
				$claim_by_user = false;
				$claim_by_session = false;
				
				if (isset($this->user))
					$claim_by_user = $this->reviews->get_shop_review_claim_by_user_id($review_id, $this->user->id);
				else
					$claim_by_session = $this->reviews->get_shop_review_claim_by_session_id($review_id, session_id());
				
				$data = array();
				
				if (!$claim_by_user && !$claim_by_session)
				{
					$claim = new stdClass;
					$claim->review_id = $review_id;
					$claim->claim_type = $review_claim_type;
					$claim->claim_text = $review_claim_text;
					$claim->user_id = isset($this->user) ? $this->user->id : NULL;
					$claim->session_id = isset($this->user) ? "" : session_id();
					$claim->id = $this->reviews->add_shop_claim($claim);
					
					$this->db->query("SELECT COUNT(id) as count FROM __reviews_shops_claims WHERE review_id=?", $review_id);
					$claims_count = $this->db->result('count');
					
					if (intval($this->settings->reviews_shop_claim_count_for_disable) > 0 && $claims_count >= $this->settings->reviews_shop_claim_count_for_disable)
						$this->reviews->update_shop_review($review_id, array('visible' => 0));
					
					$data['success'] = true;
				}
				else
				{
					$data['success'] = false;
					$data['message'] = 'exists';
				}
				
				header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($data);
				die();
			}
		}
		
        foreach($this->params_arr as $p=>$v)
        {
            switch ($p)
            {
                case "keyword":
                    if (!empty($this->params_arr[$p]))
                    {
                        $filter[$p] = $v;
                        $this->design->assign('keyword', $v);
                    }
                    else
                        unset($this->params_arr[$p]);
                    break;
                case "page":
                    if (!empty($this->params_arr[$p]))
                        $current_page = intval($v);
                    else
                        unset($this->params_arr[$p]);
                    break;
                case "sort":
                    if (!empty($this->params_arr[$p]))
                        $filter[$p] = $v;
                    else
                        unset($this->params_arr[$p]);
                    break;
                case "sort_type":
                    if (!empty($this->params_arr[$p]))
                    {
                        if (!array_key_exists('sort_type', $filter))
                            $filter[$p] = $v;
                    }
                    else
                        unset($this->params_arr[$p]);
                    break;
                case "review-images":
                    $mode = @$this->params_arr['mode'];

                    switch($mode){
                        case "upload-images":
                            $uploaded = $this->request->files('uploaded-images');
                            $temp_id = $this->request->post('object_id');

                            foreach($uploaded as $index=>$ufile)
                                $img = $this->image_temp->add_image($temp_id, $ufile['name'], $ufile['tmp_name']);

                            header("Content-type: application/json; charset=UTF-8");
                            header("Cache-Control: must-revalidate");
                            header("Pragma: no-cache");
                            header("Expires: -1");
                            print json_encode(1);
                            die();
                            break;
                        case "get-images":
                            $temp_id = $this->params_arr['temp_id'];

                            if (empty($temp_id))
                                break;

                            $this->design->assign('temp_id', $temp_id);
                            $images = $this->image_temp->get_images($temp_id);
                            $this->design->assign('images', $images);
                            $response['success'] = true;
                            $response['data'] = $this->design->fetch($this->design->getTemplateDir('frontend').'reviews-shop-images.tpl');
                            header("Content-type: application/json; charset=UTF-8");
                            header("Cache-Control: must-revalidate");
                            header("Pragma: no-cache");
                            header("Expires: -1");
                            print json_encode($response);
                            die();
                            break;
                        case "delete-image":
                            $image_id = $this->params_arr['image_id'];
                            $temp_id = $this->params_arr['temp_id'];

                            if (empty($temp_id) || empty($image_id))
                                break;

                            $this->image_temp->delete_image($temp_id, $image_id);
                            header("Content-type: application/json; charset=UTF-8");
                            header("Cache-Control: must-revalidate");
                            header("Pragma: no-cache");
                            header("Expires: -1");
                            print json_encode(1);
                            die();
                            break;
                    }

                    break;
            }
        }

		$this->design->assign('data_type', 'reviews');
		
		$all_reviews_count = $this->reviews->count_shop_reviews($filter);
		$this->design->assign('all_reviews_count', $all_reviews_count);

        /*Зададим сортировку по умолчанию*/
        if (!array_key_exists('sort', $this->params_arr))
            $filter['sort'] = 'date';

        if (!array_key_exists('sort_type', $this->params_arr))
            $filter['sort_type'] = 'desc';
		
		
		$this->design->assign('sort', $filter['sort']);
		$this->design->assign('sort_type', $filter['sort_type']);

        $this->design->assign('current_params', $this->params_arr);

        $reviews_count = $this->reviews->count_shop_reviews($filter);

        // Постраничная навигация
        if (array_key_exists('page', $this->params_arr) && $this->params_arr['page'] == 'all')
            $items_per_page = $reviews_count;
        else
            $items_per_page = 10;

        $this->design->assign('reviews_count', $reviews_count);
        $pages_num = $items_per_page>0 ? ceil($reviews_count/$items_per_page): 0;
        $this->design->assign('total_pages_num', $pages_num);

        // Если страница не задана, то равна 1
        $current_page = max(1, $current_page);
        $current_page = min($current_page, $pages_num);
        $this->design->assign('current_page_num', $current_page);

        $filter['page'] = $current_page;
        $filter['limit'] = $items_per_page;

        $todayday = new DateTime();
        $yesterday = new DateTime();
        $yesterday->modify('-1 day');
        $days_arr = array('Monday' => 'Пн',
            'Tuesday' => 'Вт',
            'Wednesday' => 'Ср',
            'Thursday' => 'Чт',
            'Friday' => 'Пт',
            'Saturday' => 'Сб',
            'Sunday' => 'Вс');

        $this->design->assign('meta_title', "Отзывы о магазине");
		$this->design->assign('meta_keywords', "Отзывы о магазине");
		$this->design->assign('meta_description', "Отзывы о магазине");

        $reviews = $this->reviews->get_shop_reviews($filter);
		foreach($reviews as $index=>$review)
			$reviews[$index]->images = $this->image->get_images('shop-reviews', $review->id);
		
        $this->design->assign('temp_id', uniqid());
        $this->design->assign('reviews', $reviews);
        $this->design->assign('params_arr', $this->params_arr);

		$review_module = $this->furl->get_module_by_name('ReviewsShopControllerAdmin');
		$this->design->assign('review_module', $review_module);

		return $this->design->fetch($this->design->getTemplateDir('frontend').'index.tpl');
	}
}