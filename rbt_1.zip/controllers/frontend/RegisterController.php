<?PHP


 
require_once('controllers/GlobalController.php');

class RegisterController extends GlobalController
{
	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}

	function fetch()
	{
		//$ajax = false;
		$action = "";
		foreach($this->params_arr as $p=>$v)
		{
			switch ($p)
			{
				case "action":
					$action = $this->params_arr[$p];
					unset($this->params_arr[$p]);
					break;
				/*case "ajax":
					$ajax = true;
					unset($this->params_arr[$p]);
					break;*/
			}
		}
		
		switch($action){
			case "register":
				$user_register = new stdClass();
				$user_register->group_id = 4;	//Зарегистрированные
				$user_register->name = $this->request->post('name');
				$user_register->password = $this->request->post('password');
				$user_register->email = $this->request->post('email');
				$user_register->enabled = 1;
				$user_register->sms_confirm = 1;
				
				$captcha_success = true;
				if ($this->settings->google_recaptcha_enabled)
				{
					$g_recaptcha_response = $this->request->post('g-recaptcha-response');
					
					$url = 'https://www.google.com/recaptcha/api/siteverify';
					$data = array(
						'secret' => $this->settings->google_recaptcha_secret_key, 
						'response' => $g_recaptcha_response,
						'remoteip' => $_SERVER['REMOTE_ADDR']);

					// use key 'http' even if you send the request to https://...
					$options = array(
						'http' => array(
							'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
							'method'  => 'POST',
							'content' => http_build_query($data),
						),
					);
					$context  = stream_context_create($options);
					$result = file_get_contents($url, false, $context);
					
					$result = json_decode($result);
					
					if (!$result->success)
					{
						$captcha_success = false;
						$this->design->assign('message_error', 'Неверная капча');
						$this->design->assign('user_register', $user_register);
						break;
					}
				}
				
				$phone = $this->request->post('phone');
				$match_res = preg_match("/^[^\(]+\(([^\)]+)\).(.+)$/", $phone, $matches);
				if ($match_res && count($matches) == 3)
				{
					$user_register->phone_code = $matches[1];
					$user_register->phone = str_replace("-","",$matches[2]);
				}
				
				$phone_filter = "";
				if (!empty($user_register->phone_code) && !empty($user_register->phone))
					$phone_filter = $this->db->placehold("phone_code=? AND phone=?", $user_register->phone_code, $user_register->phone);
				
				//Проверим нет ли уже такого пользователя
				$query = $this->db->placehold("SELECT COUNT(id) as kol FROM __access_users WHERE email=?", $user_register->email);
				$this->db->query($query);
				$count_users_email = $this->db->result('kol');
				
				$count_users_phone = 0;
				if (!empty($phone_filter))
				{
					$query = $this->db->placehold("SELECT COUNT(id) as kol FROM __access_users WHERE $phone_filter");
					$this->db->query($query);
					$count_users_phone = $this->db->result('kol');
				}
				
				if ($count_users_email == 0 && $count_users_phone == 0)
				{
					$user_register->id = @$this->users->add_user($user_register);
					if ($user_register->id)
					{
						$this->design->assign('message_success', 'added');
						$this->notify_email->email_new_user($user_register->id);
						@ini_set('session.gc_maxlifetime', $this->settings->session_lifetime);	// 86400 = 24 часа
						@ini_set('session.cookie_lifetime', 0); 				// 0 - пока браузер не закрыт
						session_start();
						$_SESSION['id'] = session_id();
						$_SESSION['user_id'] = $user_register->id;
						$_SESSION['show_success_registration'] = true;
						header('Location: '.$this->config->root_url);
					}
					else
						$this->design->assign('message_error', 'error');
				}
				else
					if ($count_users_email > 0)
						$this->design->assign('message_error', 'Пользователь с такой почтой уже есть');
					else
						$this->design->assign('message_error', 'Пользователь с таким телефоном уже есть');
				
				$this->design->assign('user_register', $user_register);
			break;
		}
		

	
		$this->design->assign('meta_title', "Регистрация");
		$this->design->assign('meta_keywords', "Регистрация");
		$this->design->assign('meta_description', "Регистрация");

		return $this->design->fetch($this->design->getTemplateDir('frontend').'register.tpl');
	}
}