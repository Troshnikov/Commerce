<?PHP


 
require_once('controllers/GlobalController.php');

class LoginController extends GlobalController
{
	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}

	function fetch()
	{
		if (array_key_exists('logout', $this->params_arr))
		{
			
			unset($_SESSION['admin']);
			unset($_SESSION['user_id']);
			header('Location: '.$this->config->root_url);
		}
		
		$method = $this->request->method('post') ? 'post' : 'get';
		$mode = 'login';
		
		foreach($this->params_arr as $p=>$v)
		{
			switch ($p)
			{
				case "mode":
					$mode = $v;
					if (!in_array($mode, array('login', 'forgot-password', 'new-password')))
						$mode = 'login';
					break;
			}
		}
		
		if ($this->request->post('token'))
			$mode = 'ulogin';
		
		if ($method == 'post')
		{
			switch($mode){
				case 'login':
					$error_message = "";
					$username = $this->request->post('username');
					$password = $this->request->post('password');
					
					if($user_id = $this->users->check_password($username, $password))
					{
						$user = $this->users->get_user($user_id);
						$granted = $this->users->check_permission($user_id, "LoginControllerAdmin", "admin");
						if($user->enabled)
						{
							@ini_set('session.gc_maxlifetime', $this->settings->session_lifetime);	// 86400 = 24 часа
							@ini_set('session.cookie_lifetime', 0); 				// 0 - пока браузер не закрыт
							session_start();
							$_SESSION['id'] = session_id();
							$_SESSION['user_id'] = $user->id;
							if ($granted)
								$_SESSION['admin'] = "admin";
							$account_module = $this->furl->get_module_by_name('AccountController');
							header('Location: '.$this->config->root_url/*.$account_module->url*/);
						}
						else
							if (!$user->enabled)
								$error_message = "account_disabled";
							else
								$error_message = "access_denied";
					}
					else
						$error_message = "auth_error";

					if (!empty($error_message))
					{
						$this->design->assign('username', $username);
						$this->design->assign('error_message', $error_message);
					}
					break;
				case 'ulogin':
					$error_message = "";
					
					$s = file_get_contents('http://ulogin.ru/token.php?token=' . $this->request->post('token') . '&host=' . $_SERVER['HTTP_HOST']);
					$user = $s ? json_decode($s, true) : array();
					
					if (!empty($user) && !isset($user['error']))
					{
						$network = $user['network'];
						$network_uid = $user['uid'];
						$user_id = 0;
						
						$social_user = $this->users->get_user_social_network($network, $network_uid);
						
						var_dump($social_user);
						
						if (empty($social_user))
						{
							$db_user = $this->users->get_user($user['email']);
							var_dump($db_user);
							
							if (!empty($db_user))
							{
								//Пользователь с таким email найден, привязываем соц сеть к существующему аккаунту
								$user_social = new stdClass();
								$user_social->user_id = $db_user->id;
								$user_social->network = $network;
								$user_social->network_uid = $network_uid;
								$user_social->ulogin_data = $s;
								
								$user_social->id = $this->users->add_user_social_network($user_social);
								$user_id = $db_user->id;
							}
							else
							{
								//die('Создание юзера в процессе работы! Create user under construction! Erstellen Sie einen Benutzer in den Prozess der!');
								//Пользователь не найден, создаем нового
								$user_register = new stdClass();
								$user_register->group_id = 4;	//Зарегистрированные
								$user_register->name = trim((array_key_exists('first_name', $user) ? $user['first_name'] : '') . ' ' . (array_key_exists('last_name', $user) ? $user['last_name'] : ''));
								$user_register->password = uniqid();
								$user_register->email = array_key_exists('email', $user) ? $user['email'] : '';
								$user_register->enabled = 1;
								$user_register->mail_confirm = 1;
								$user_register->sms_confirm = 1;
								
								$user_register->id = $this->users->add_user($user_register);
								$user_id = $user_register->id;
								
								//Добавляем к нему аккаунт соц сети
								$user_social = new stdClass();
								$user_social->user_id = $user_register->id;
								$user_social->network = $network;
								$user_social->network_uid = $network_uid;
								$user_social->ulogin_data = $s;
								
								$user_social->id = $this->users->add_user_social_network($user_social);
							}
						}
						else
						{
							//Пользователь найден, входим
							$user_id = $social_user->user_id;
						}
						
						//Если есть ID для входа, то входим по нему
						if (!empty($user_id))
						{
							$user = $this->users->get_user($user_id);
							$granted = $this->users->check_permission($user->id, "LoginControllerAdmin", "admin");
							if($user->enabled)
							{
								@ini_set('session.gc_maxlifetime', $this->settings->session_lifetime);	// 86400 = 24 часа
								@ini_set('session.cookie_lifetime', 0); 								// 0 - пока браузер не закрыт
								session_start();
								$_SESSION['id'] = session_id();
								$_SESSION['user_id'] = $user->id;
								if ($granted)
									$_SESSION['admin'] = "admin";
								$account_module = $this->furl->get_module_by_name('AccountController');
								header('Location: '.$this->config->root_url);
							}
							else
								if (!$user->enabled)
									$error_message = "account_disabled";
								else
									$error_message = "access_denied";
						}
					}
					else
						$error_message = "auth_error";
					
					break;
				case 'forgot-password':
					$error_message = "";
					$success_message = "";
					$email = $this->request->post('email');
					$user = $this->users->get_user($email);
					if (!$user)
						$error_message = "user_not_found";
					else
					{
						$reset_url = md5($this->salt . $user->password . md5($user->password) . $user->id);
						$datetime = new DateTime();
						$datetime->modify('+1 day');
						$reset_date = $datetime->format('Y-m-d G:i');
						
						$this->users->update_user($user->id, array('reset_url'=> $reset_url, 'reset_date'=> $reset_date));
						$this->notify_email->email_reset_password($user->id);
						$success_message = "mail_sended";
					}
					if (!empty($error_message))
						$this->design->assign('error_message', $error_message);
					if (!empty($success_message))
						$this->design->assign('success_message', $success_message);
					break;
				case "new-password":
					$reset_url = $this->request->post('reset_code');
					$password1 = $this->request->post('password1');
					$password2 = $this->request->post('password2');
					$error_message = "";
					if (empty($reset_url))
						$error_message = "empty_reset_code";
					elseif(empty($password1) || empty($password2) || $password1!=$password2)
						$error_message = "password_error";
					else
					{
						$this->db->query("SELECT * FROM __access_users WHERE reset_url=?", $reset_url);
						$user = $this->db->result();
						if (!$user)
							$error_message = "invalid_reset_code";
						else
						{
							$this->users->update_user($user->id, array('password'=>$password1, 'reset_url'=>''));
							$success_message = "password_changed";
						}
					}
					if (!empty($error_message))
						$this->design->assign('error_message', $error_message);
					if (!empty($success_message))
						$this->design->assign('success_message', $success_message);
					break;
			}
		}
		else
		{
			switch($mode)
			{
				case "new-password":
					$reset_url = $this->request->get('reset_code');
					$error_message = "";
					if (empty($reset_url))
						$error_message = "empty_reset_code";
					else
					{
						$this->db->query("SELECT * FROM __access_users WHERE reset_url=?", $reset_url);
						$user = $this->db->result();
						if (!$user)
							$error_message = "invalid_reset_code";
						else
						{
							$this->design->assign('reset_code', $reset_url);
							$this->design->assign('user_node', $user);
						}
					}
					if (!empty($error_message))
						$this->design->assign('error_message', $error_message);
					break;
			}
		}
	
		$this->design->assign('meta_title', 'Вход в личный кабинет');
		$this->design->assign('meta_keywords', 'Вход в личный кабинет');
		$this->design->assign('meta_description', 'Вход в личный кабинет');
		
		if ($mode == 'ulogin')
			$mode = 'login';
		
		return $this->design->fetch($this->design->getTemplateDir('frontend').$mode.'.tpl');
	}
}