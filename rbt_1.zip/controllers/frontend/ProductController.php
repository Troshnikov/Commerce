<?PHP


 
require_once('controllers/GlobalController.php');

class ProductController extends GlobalController
{
	private $param_url, $params_arr, $options;
	
	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				if (array_key_exists($x[0], $this->params_arr) && count($x)>1)
				{
					$this->params_arr[$x[0]] = (array) $this->params_arr[$x[0]];
					$this->params_arr[$x[0]][] = $x[1];
				}
				else
				{
					$this->params_arr[$x[0]] = "";
					if (count($x)>1)
						$this->params_arr[$x[0]] = $x[1];
				}
			}
		}
	}
	
	private function make_categories_lazy_tree(&$tree, $category_path)
	{
		$next_id = @reset($category_path);
		foreach($tree as &$t)
			if ($t['id'] == $next_id)
			{
				$t['subcategories'] = $this->categories->get_categories_lazy_load_filter(array('parent_id'=>$next_id, 'visible'=>1));
				if (count($category_path) > 1)
				{
					array_shift($category_path);
					$this->make_categories_lazy_tree($t['subcategories'], $category_path);
				}
			}
	}

	function fetch()
	{
		$ajax = false;
		$variant_id = 0;
		
		if ($this->request->method('post'))
		{
			$val = $this->request->post('val');
			$votes = $this->request->post('votes');
			$product_id = $this->request->post('product_id');
			$score = $this->request->post('score');
			
			$review_name = $this->request->post('name');
			$review_short = $this->request->post('short');
			$review_pluses = $this->request->post('pluses');
			$review_minuses = $this->request->post('minuses');
			$review_comments = $this->request->post('comments');
			$review_recommended = $this->request->post('recommended');
			$review_rating = $this->request->post('rating', 'integer');
			$review_temp_id = $this->request->post('temp_id');
			
			$review_id = $this->request->post('review_id', 'integer');
			$review_helpful = $this->request->post('helpful', 'integer');
			$review_nothelpful = $this->request->post('nothelpful', 'integer');
			
			$review_claim_type = $this->request->post('claim_type');
			$review_claim_text = $this->request->post('claim_text');
			
			if (!empty($val) && !empty($votes) && !empty($product_id) && !empty($score)){
				$rate_by_user = false;
				$rate_by_session = false;
				
				if (isset($this->user))
					$rate_by_user = $this->reviews->get_product_rate_by_user_id($product_id, $this->user->id);
				else
					$rate_by_session = $this->reviews->get_product_rate_by_session_id($product_id, session_id());
				
				if (!$rate_by_user && !$rate_by_session)
				{
					$rate = new stdClass;
					$rate->product_id = $product_id;
					$rate->rating = $score;
					$rate->user_id = isset($this->user) ? $this->user->id : NULL;
					$rate->session_id = isset($this->user) ? "" : session_id();
					$rate->moderated = 1;
					$rate->id = $this->reviews->add_review($rate);
				}
				else
				{
					$rate = new stdClass;
					$rate->rating = $score;
					if ($rate_by_user !== false)
						$rate->id = $this->reviews->update_review($rate_by_user->id, $rate);
					if ($rate_by_session !== false)
						$rate->id = $this->reviews->update_review($rate_by_session->id, $rate);
				}
				
				$data = array();
				if (!empty($rate->id))
					$data['status'] = 'OK';
				else
					$data['status'] = '';
				
				$product_rating = $this->reviews->calc_product_rating($product_id);
				$data['score'] = $product_rating->avg_rating;
				$data['votes'] = $product_rating->rating_count;
				
				header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($data);
				die();
			}
			
			if (!empty($product_id) && isset($review_name) && isset($review_short) && isset($review_pluses) && isset($review_minuses) && isset($review_comments) && isset($review_recommended) && isset($review_rating)){
				
				$review_by_user = false;
				$review_by_session = false;
				
				$is_admin = false;
				
				if (isset($this->user)){
					$review_by_user = $this->reviews->get_product_rate_by_user_id($product_id, $this->user->id);
					
					$granted = $this->users->check_permission($this->user->id, "LoginControllerAdmin", "admin");
					if($granted)
						$is_admin = true;
				}
				else
					$review_by_session = $this->reviews->get_product_rate_by_session_id($product_id, session_id());
				
				if ((!$review_by_user && !$review_by_session) || $is_admin)
				{
					$review = new stdClass;
					$review->rating = $review_rating;
					$review->product_id = $product_id;
					$review->name = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_name);
					$review->short = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_short);
					$review->pluses = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_pluses);
					$review->minuses = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_minuses);
					$review->comments = preg_replace ("!<a.*?href=\"?'?([^ \"'>]+)\"?'?.*?>(.*?)</a>!is", "\\2", $review_comments);
					$review->recommended = $review_recommended;
					if (isset($this->user))
						$review->user_id = $this->user->id;
					else
						$review->session_id = session_id();
					$review->id = $this->reviews->add_review($review);
					
					$tmp_product = $this->products->get_product($product_id);
					
					$images = $this->image_temp->get_images($review_temp_id);
					if (!empty($images)){
						foreach($images as $i){
							$fname = $this->config->root_dir . '/' . $this->config->original_tempimages_dir . $i->filename;
							$this->image->add_internet_image('reviews', $review->id, $this->furl->generate_url($tmp_product->name), $fname);
							$this->image_temp->delete_image($i->temp_id, $i->id);
						}
					}
				}
				else
				{
					$review->rating = $review_rating;
					$review->name = $review_name;
					$review->short = $review_short;
					$review->pluses = $review_pluses;
					$review->minuses = $review_minuses;
					$review->comments = $review_comments;
					$review->recommended = $review_recommended;
					if ($review_by_user)
						$review->id = $review_by_user->id;
					else
						$review->id = $review_by_session->id;
					
					$this->reviews->update_review($review->id, $review);
					
					$images = $this->image->get_images('reviews', $review->id);
					foreach($images as $i)
						$this->image->delete_image('reviews', $review->id, $i->id);
					
					$tmp_product = $this->products->get_product($product_id);
					
					$images = $this->image_temp->get_images($review_temp_id);
					if (!empty($images)){
						foreach($images as $i){
							$fname = $this->config->root_dir . '/' . $this->config->original_tempimages_dir . $i->filename;
							$this->image->add_internet_image('reviews', $review->id, $this->furl->generate_url($tmp_product->name), $fname);
							$this->image_temp->delete_image($i->temp_id, $i->id);
						}
					}
				}
				
				header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($review->id);
				die();
			}
			
			if (!empty($review_id) && (!empty($review_helpful) || !empty($review_nothelpful))){
				$response_by_user = false;
				$response_by_session = false;
				
				if (isset($this->user))
					$response_by_user = $this->reviews->get_review_response_by_user_id($review_id, $this->user->id);
				else
					$response_by_session = $this->reviews->get_review_response_by_session_id($review_id, session_id());
				
				$data = array();
				
				if (!$response_by_user && !$response_by_session)
				{
					$response = new stdClass;
					$response->review_id = $review_id;
					$response->helpful = $review_helpful;
					$response->nothelpful = $review_nothelpful;
					$response->user_id = isset($this->user) ? $this->user->id : NULL;
					$response->session_id = isset($this->user) ? "" : session_id();
					$response->id = $this->reviews->add_response($response);
					
					$review = $this->reviews->get_review($review_id);
					if ($review_helpful)
						$this->reviews->update_review($review_id, array('helpful' => $review->helpful + 1));
					else
						$this->reviews->update_review($review_id, array('nothelpful' => $review->nothelpful + 1));
					
					$data['success'] = true;
					$data['helpful'] = $review_helpful ? $review->helpful + 1 : $review->helpful;
					$data['nothelpful'] = $review_nothelpful ? $review->nothelpful + 1 : $review->nothelpful;
				}
				else
				{
					$data['success'] = false;
					$data['message'] = 'exists';
				}
				
				header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($data);
				die();
			}
			if (!empty($review_id) && isset($review_claim_type) && isset($review_claim_text)){
				$claim_by_user = false;
				$claim_by_session = false;
				
				if (isset($this->user))
					$claim_by_user = $this->reviews->get_review_claim_by_user_id($review_id, $this->user->id);
				else
					$claim_by_session = $this->reviews->get_review_claim_by_session_id($review_id, session_id());
				
				$data = array();
				
				if (!$claim_by_user && !$claim_by_session)
				{
					$claim = new stdClass;
					$claim->review_id = $review_id;
					$claim->claim_type = $review_claim_type;
					$claim->claim_text = $review_claim_text;
					$claim->user_id = isset($this->user) ? $this->user->id : NULL;
					$claim->session_id = isset($this->user) ? "" : session_id();
					$claim->id = $this->reviews->add_claim($claim);
					
					$this->db->query("SELECT COUNT(id) as count FROM __reviews_claims WHERE review_id=?", $review_id);
					$claims_count = $this->db->result('count');
					
					if (intval($this->settings->reviews_claim_count_for_disable) > 0 && $claims_count >= $this->settings->reviews_claim_count_for_disable)
						$this->reviews->update_review($review_id, array('visible' => 0));
					
					$data['success'] = true;
				}
				else
				{
					$data['success'] = false;
					$data['message'] = 'exists';
				}
				
				header("Content-type: application/json; charset=UTF-8");
				header("Cache-Control: must-revalidate");
				header("Pragma: no-cache");
				header("Expires: -1");
				print json_encode($data);
				die();
			}
		}
	
		if (!empty($this->param_url))
		{
			$str = trim($this->param_url, '/');
			$params = explode('/', $str);
			
			$filter = array('limit' => 1);
			
			if (empty($_SESSION['admin']) || $_SESSION['admin'] != 'admin')
				$filter['visible'] = 1;
				
			$product_url = $this->param_url;
			$filter['url'] = $product_url;
			$product = @reset($this->products->get_products($filter));
			
			foreach($this->params_arr as $p=>$v)
			{
				switch ($p)
				{
					case "ajax":
						$ajax = intval($v);
						unset($this->params_arr[$p]);
						break;
					case "variant":
						$this->design->assign('variant_id', intval($v));
						break;
					case "tab":
						$this->design->assign('tab', $v);
						break;
					case "page":
						$this->design->assign('page', $v);
						break;
					case "sort":
						$this->design->assign('sort', $v);
						break;
				}
			}
		}
	
		if ($product)
		{
			$this->products->update_product($product->id, array('like_opened' => $product->like_opened+1));
			
			$product->images = $this->image->get_images('products', $product->id);
			$product->image = reset($product->images);
			$product->attachments = $this->attachments->get_attachments('products', $product->id);
			$product->rating = $this->reviews->calc_product_rating($product->id);
			if (isset($this->user))
				$product->rate_by_user = $this->reviews->get_product_rate_by_user_id($product->id, $this->user->id);
			else
				$product->rate_by_user = $this->reviews->get_product_rate_by_session_id($product->id, session_id());

			$variants_filter = array('product_id'=>$product->id, 'visible'=>1);
			if ($this->settings->catalog_default_variants_sort == "stock")
				$variants_filter['sort'] = $this->db->placehold('abs(IFNULL(v.stock, ?)) desc, stock desc', $this->settings->max_order_amount);
			else
				$variants_filter['sort'] = $this->settings->catalog_default_variants_sort;
				
			$product->variants = $this->variants->get_variants($variants_filter);
			
			if ($this->settings->catalog_hide_nostock_variants && count($product->variants) > 1)
				foreach($product->variants as $index2=>$v)
					if ($v->stock == 0)
						unset($product->variants[$index2]);
			
			$cart = $this->cart->get_cart();
			foreach($product->variants as $idx=>$v)
			{
				$product->variants[$idx]->stock_available = $v->stock == -1 ? 999 : $v->stock;
				foreach($cart->purchases as $p)
					if ($p->variant->id == $v->id)
						$product->variants[$idx]->stock_available -= $p->amount;
			}
			
			if (!empty($variant_id))
			{
				foreach($product->variants as $v)
					if ($v->id == $variant_id)
						$product->variant = $v;
			}
			else
				$product->variant = reset($product->variants);
			
			$in_stock = false;
			foreach($product->variants as $v)
				if ($v->stock != 0)
					$in_stock = true;
			if (!$in_stock && $this->settings->catalog_show_all_products)
				return false;
			
			$product->badges = $this->badges->get_product_badges($product->id);
			
			if (!empty($this->user))
				$product->is_favorite = $this->products->check_favorite_product($product->id, $this->user->id);
			
			$product_categories = $this->categories->get_product_categories($product->id);
			if ($product_categories)
			{
				$product_category = reset($product_categories);
				$category = $this->categories->get_category($product_category->category_id);
				if ($category)
				{
					$this->design->assign('category', $category);
					$this->design->assign('body_category_css', $category->css_class);
					$this->design->assign('category_id', $category->id);
					//Составим путь выборки категории, чтоб подгрузить ее во фронтенде
					$category_path = array();
					$tmp_category = $category;
					while($tmp_category->parent_id != 0)
					{
						$tmp_category = $this->categories->get_category(intval($tmp_category->parent_id));
						$category_path[] = $tmp_category->id;
					}
					$category_path = array_reverse($category_path);
					
					//Подготовим статическое меню для фронтенда
					$categories_frontend = $this->categories->get_categories_lazy_load_filter(array('parent_id'=>0, 'visible'=>1));
					$this->make_categories_lazy_tree($categories_frontend, array_merge($category_path, array($category->id)));
					$this->design->assign('categories_frontend', $categories_frontend);
					
					$category_path = join(",", $category_path);
					$this->design->assign('category_path', $category_path);
					
					//Свойства, которые входят в фильтр категории
					$groups_ids = array();
					$set_tag_groups = $this->tags->get_tags_set_tags(array('category_id'=>$category->id));
					foreach($set_tag_groups as $gr)
						$groups_ids[] = $gr->group_id;
					
					// Свойства товара
					$product_tags = $this->tags->get_product_tags($product->id);
					foreach($product_tags as $idx=>$t)
					{
						$product_tags[$idx]->images = $this->image->get_images('tags', $t->id);
						$product_tags[$idx]->image = @reset($product_tags[$idx]->images);
					}
					$product_tags_groups = array();
					foreach($product_tags as $tag)
					{
						if (!array_key_exists($tag->group_id, $product_tags_groups))
							$product_tags_groups[$tag->group_id] = array();
						$product_tags_groups[$tag->group_id][] = $tag;
					}
					$this->design->assign('product_tags', $product_tags_groups);
				}
			}
			$reviews_count = $this->reviews->count_reviews(array('product_id'=>$product->id, 'visible'=>1, 'moderated'=>1));
			$this->design->assign('reviews_count', $reviews_count);
		}
		else
			return false;
		
		if (!empty($product->modificators))
			$product->modificators = explode(',', $product->modificators);
		else
			$product->modificators = array();
		if (!empty($product->modificators_groups) && !is_array($product->modificators_groups))
			$product->modificators_groups = explode(',', $product->modificators_groups);
		else
			$product->modificators_groups = array();
		
		$this->design->assign('product', $product);
		$this->design->assign('body_product_css', $product->css_class);
		
		$count_related_products = $this->products->count_related_products(array('product_id'=>$product->id, 'product_type'=>0, 'visible'=>1));
		$this->design->assign('count_related_products', $count_related_products);
		
		//$count_analogs_products = $this->products->count_related_products(array('product_id'=>$product->id, 'product_type'=>3, 'visible'=>1));
		$analog_product = $this->products->get_analog_product_by_product_id($product->id);
		if ($analog_product)
		{
			$count_analogs_products = $this->products->count_analogs_products(array('group_id' => $analog_product->group_id, 'visible' => 1, 'exclude_id' => $product->id));
			$this->design->assign('count_analogs_products', $count_analogs_products);
		}
		
		$tags_groups = $this->tags->get_taggroups(array('is_auto'=>0, 'enabled'=>1));
		$this->design->assign('tags_groups', $tags_groups);
		
		if (file_exists("modules/analogs/controller/analogs_frontend.php"))
		{
			include_once("modules/analogs/controller/analogs_frontend.php");
			$ext_module_name = 'AnalogsFrontendController';
			$ext_module = new $ext_module_name();
			$autoanalogs_template = $ext_module->get_analogs(['product' => $product, 'tags' => $product_tags_groups]);
			$this->design->assign('autoanalogs_template', $autoanalogs_template);
		}
		
		if (file_exists("modules/related/controller/related_frontend.php"))
		{
			include_once("modules/related/controller/related_frontend.php");
			$ext_module_name = 'RelatedFrontendController';
			$ext_module = new $ext_module_name();
			$autorelated_template = $ext_module->get_related(['product' => $product, 'tags' => $product_tags_groups]);
			$this->design->assign('autorelated_template', $autorelated_template);
		}
		
		// Добавление в историю просмотров товаров
		$count_history_products = $this->settings->count_history_products; // Максимальное число хранимых товаров в истории
		$expire = time()+60*60*24*30; // Время жизни - 30 дней
		if(!empty($_COOKIE['history_products']))
		{
			$history_products = explode(',', $_COOKIE['history_products']);
			if(($exists = array_search($product->id, $history_products)) !== false)
				unset($history_products[$exists]);
		}
		// Добавим текущий товар
		$history_products[] = $product->id;
		$cookie_val = implode(',', array_slice($history_products, -$count_history_products, $count_history_products));
		setcookie("history_products", $cookie_val, $expire, "/");
		
		$modificators = $this->modificators->get_modificators(array('visible' => 1));
		$modificators_groups = array();
		
		$all_group = new stdClass;
		$all_group->name = '';
		$all_group->id = 0;
		$all_group->parent_id = null;
		$all_group->type = 'checkbox';
		$all_group->modificators = array();
		$modificators_groups[0] = $all_group;
		foreach($this->modificators->get_modificators_groups(array('visible' => 1)) as $group){
			$group->modificators = array();
			$modificators_groups[$group->id] = $group;
		}
			
		foreach($modificators as $m){
			if (!isset($m->parent_id))
				$m->parent_id = 0;
			$m->images = $this->image->get_images('modificators', $m->id);
			$m->image = @reset($m->images);
			$modificators_groups[$m->parent_id]->modificators[] = $m;
		}
		
		$keys = array_keys($modificators_groups);
		if (!empty($keys))
		foreach($keys as $key)
			if (count($modificators_groups[$key]->modificators) == 0)
				unset($modificators_groups[$key]);
		
		$this->design->assign('modificators_groups', $modificators_groups);
		
		/*if (!empty($product))

		{
			$meta_title = $this->settings->prefix_product;
			if (!empty($meta_title))
				$meta_title .= ' ';
			$meta_title .= $product->meta_title;
			$postfix = $this->settings->postfix_product;
			if (!empty($postfix))
				$meta_title .= ' ' . $postfix;
			$this->design->assign('meta_title', $meta_title);
			$this->design->assign('meta_description', $product->meta_description);
			$this->design->assign('meta_keywords', $product->meta_keywords);
		}*/
		if (!empty($product))
		{
			$meta_title = $this->settings->seo_product_title;
			$meta_keywords = $this->settings->seo_product_keywords;
			$meta_description = $this->settings->seo_product_description;
			
			$meta_title = str_replace('{product_name}', $product->name, $meta_title);
			$meta_title = str_replace('{product_title}', $product->meta_title, $meta_title);
			$meta_title = str_replace('{product_keywords}', $product->meta_keywords, $meta_title);
			$meta_title = str_replace('{product_description}', $product->meta_description, $meta_title);
			$meta_title = str_replace('{product_brand}', !empty($brand) ? (!empty($brand->frontend_name) ? $brand->frontend_name : $brand->name) : '', $meta_title);
			$meta_title = str_replace('{product_collection}', !empty($collection) ? (!empty($collection->frontend_name) ? $collection->frontend_name : $collection->name) : '', $meta_title);
			$meta_title = str_replace('{product_category}', !empty($category) ? (!empty($category->frontend_name) ? $category->frontend_name : $category->name) : '', $meta_title);
			
			$meta_keywords = str_replace('{product_name}', $product->name, $meta_keywords);
			$meta_keywords = str_replace('{product_title}', $product->meta_title, $meta_keywords);
			$meta_keywords = str_replace('{product_keywords}', $product->meta_keywords, $meta_keywords);
			$meta_keywords = str_replace('{product_description}', $product->meta_description, $meta_keywords);
			$meta_keywords = str_replace('{product_brand}', !empty($brand) ? (!empty($brand->frontend_name) ? $brand->frontend_name : $brand->name) : '', $meta_keywords);
			$meta_keywords = str_replace('{product_collection}', !empty($collection) ? (!empty($collection->frontend_name) ? $collection->frontend_name : $collection->name) : '', $meta_keywords);
			$meta_keywords = str_replace('{product_category}', !empty($category) ? (!empty($category->frontend_name) ? $category->frontend_name : $category->name) : '', $meta_keywords);
			
			$meta_description = str_replace('{product_name}', $product->name, $meta_description);
			$meta_description = str_replace('{product_title}', $product->meta_title, $meta_description);
			$meta_description = str_replace('{product_keywords}', $product->meta_keywords, $meta_description);
			$meta_description = str_replace('{product_description}', $product->meta_description, $meta_description);
			$meta_description = str_replace('{product_brand}', !empty($brand) ? (!empty($brand->frontend_name) ? $brand->frontend_name : $brand->name) : '', $meta_description);
			$meta_description = str_replace('{product_collection}', !empty($collection) ? (!empty($collection->frontend_name) ? $collection->frontend_name : $collection->name) : '', $meta_description);
			$meta_description = str_replace('{product_category}', !empty($category) ? (!empty($category->frontend_name) ? $category->frontend_name : $category->name) : '', $meta_description);
			
			$this->design->assign('meta_title', $meta_title);
			$this->design->assign('meta_keywords', $meta_keywords);
			$this->design->assign('meta_description', $meta_description);
		}
		
		if ($ajax)
		{
			$data = array('success'=>true, 'body_category_css'=>isset($category)?$category->css_class:'', 'body_product_css'=>$product->css_class, 'data'=>$this->design->fetch($this->design->getTemplateDir('frontend').'product.tpl'), 'category_path'=>isset($category_path)?$category_path:'', 'category_id'=>!empty($category)?$category->id:'', 'meta_title'=>$meta_title, 'meta_keywords'=>$product->meta_keywords, 'meta_description'=>$product->meta_description);
			header("Content-type: application/json; charset=UTF-8");
			header("Cache-Control: must-revalidate");
			header("Pragma: no-cache");
			header("Expires: -1");
			print json_encode($data);
			die();
		}
	
		return $this->design->fetch($this->design->getTemplateDir('frontend').'product.tpl');
	}
}