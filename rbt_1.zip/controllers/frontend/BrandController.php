<?PHP


 
require_once('controllers/GlobalController.php');

class BrandController extends GlobalController
{
	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null)
	{
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				if (array_key_exists($x[0], $this->params_arr) && count($x)>1)
				{
					$this->params_arr[$x[0]] = (array) $this->params_arr[$x[0]];
					$this->params_arr[$x[0]][] = $x[1];
				}
				else
				{
					$this->params_arr[$x[0]] = "";
					if (count($x)>1)
						$this->params_arr[$x[0]] = $x[1];
				}
			}
		}
	}

	function fetch()
	{
		$brand = $this->brands->get_brand($this->param_url);
		if ($brand)
		{
			$brand_id = $brand->id;
			$this->design->assign('brand', $brand);
		}
		else
			return false;
		
		$ajax = false;
		$filter = array();
		$filter['brand_id'] = $brand->id;
		$filter['visible'] = 1;
		$filter['limit'] = 10000;
		if ($this->settings->catalog_show_all_products)
			$filter['in_stock'] = 1;
		$current_page = 1;
		
		foreach($this->params_arr as $p=>$v)
		{
			switch ($p)
			{
				case "page":
					if (!empty($v))
						if ($v == "all")
							$current_page = "all";
						else
							$current_page = intval($v);
					else
						unset($this->params_arr[$p]);
					break;
				case "ajax":
					$ajax = intval($v);
					unset($this->params_arr[$p]);
					break;
				case "sort":
					if (!empty($v))
						$filter[$p] = $v;
					else
						unset($this->params_arr[$p]);
					break;
				case "sort_type":
					if (!empty($v))
					{
						if (!array_key_exists('sort_type', $filter))
							$filter[$p] = $v;
					}
					else
						unset($this->params_arr[$p]);
					break;
			}
		}
		
		$sort_methods = array();
		if ($this->settings->settings_sort_position)
            $sort_methods[] = 'position';
		if ($this->settings->settings_sort_price){
			$sort_methods[] = 'price_asc';
			$sort_methods[] = 'price_desc';
		}
		if ($this->settings->settings_sort_popular){
			$sort_methods[] = 'popular_asc';
			$sort_methods[] = 'popular_desc';
		}
		if ($this->settings->settings_sort_newest){
			$sort_methods[] = 'newest_asc';
			$sort_methods[] = 'newest_desc';
		}
		if ($this->settings->settings_sort_name){
			$sort_methods[] = 'name_asc';
			$sort_methods[] = 'name_desc';
		}
		
		/*Зададим сортировку по умолчанию*/
		if (!array_key_exists('sort', $this->params_arr))
		{
			$filter['sort'] = reset($sort_methods);//'position';
			$filter['sort_type'] = 'asc';
			$sort_type = $this->settings->catalog_default_sort;
			if (!in_array($sort_type, $sort_methods))
				$sort_type = reset($sort_methods);
			switch($sort_type){
				case 'position':
					$filter['sort'] = 'position';
					$filter['sort_type'] = 'asc';
					break;
				case 'price_asc':
					$filter['sort'] = $this->params_arr['sort'] = 'price';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'asc';
					break;
				case 'price_desc':
					$filter['sort'] = $this->params_arr['sort'] = 'price';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'desc';
					break;
				case 'popular_asc':
					$filter['sort'] = $this->params_arr['sort'] = 'popular';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'asc';
					break;
				case 'popular_desc':
					$filter['sort'] = $this->params_arr['sort'] = 'popular';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'desc';
					break;
				case 'newest_asc':
					$filter['sort'] = $this->params_arr['sort'] = 'newest';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'asc';
					break;
				case 'newest_desc':
					$filter['sort'] = $this->params_arr['sort'] = 'newest';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'desc';
					break;
				case 'name_asc':
					$filter['sort'] = $this->params_arr['sort'] = 'name';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'asc';
					break;
				case 'name_desc':
					$filter['sort'] = $this->params_arr['sort'] = 'name';
					$filter['sort_type'] = $this->params_arr['sort_type'] = 'desc';
					break;
			}
		}
		else
			if (!array_key_exists('sort_type', $this->params_arr))
				$filter['sort_type'] = 'asc';
		
		/*Зададим формат вывода по умолчанию*/
		if (!array_key_exists('mode', $this->params_arr))
			$this->design->assign('mode', $this->settings->default_show_mode);
		else
			$this->design->assign('mode', $this->params_arr['mode']);
		
		$this->design->assign('current_url', $this->param_url.(empty($this->param_url)?'':'/'));
		$this->design->assign('current_params', $this->params_arr);
		// Если страница не задана, то равна 1
		if (is_numeric($current_page))
			$current_page = max(1, $current_page);
		$this->design->assign('current_page_num', $current_page);
		
		if (!empty($brand))
		{
			$tag_set = $this->tags->get_tags_set(31);
			if (!empty($tag_set) && $tag_set->visible)
			{
				$this->design->assign('tag_set', $tag_set);
				if (!empty($tag_set->id))
				{
					$filter_tags = array('enabled' => 1, 'brand_id' => $brand->id);
					$tags_groups = $this->tags->get_tags_set_tags(array('set_id'=>31, 'in_filter'=>1));
					
					foreach($tags_groups as $index=>$tag_group)
					{
						if ((array_key_exists($tag_group->name_translit, $this->params_arr) || !$ajax || array_key_exists('page', $this->params_arr)))
						{
							if (!array_key_exists('tags', $filter_tags))
								$filter_tags['tags'] = array();
							/*if ($tag_group->mode == "range")
							{
								$filter_tags['tags'][$tag_group->group_id] = new StdClass;
								$filter_tags['tags'][$tag_group->group_id]->from = $category_pre_tags_range_groups[$tag_group->name_translit]['from'];
								$filter_tags['tags'][$tag_group->group_id]->to = $category_pre_tags_range_groups[$tag_group->name_translit]['to'];
							}
							else
								$filter_tags['tags'][$tag_group->group_id] = $category_pre_tags_groups[$tag_group->name_translit];*/
						}
					
						if (array_key_exists($tag_group->name_translit, $this->params_arr))
						{
							if (!array_key_exists('tags', $filter_tags))
								$filter_tags['tags'] = array();
							if ($this->params_arr[$tag_group->name_translit] != '0')
								if ($tag_group->mode == "range")
								{
									$v = explode(';', $this->params_arr[$tag_group->name_translit]);
									if (count($v) == 2)
									{
										$filter_tags['tags'][$tag_group->group_id] = new StdClass;
										$filter_tags['tags'][$tag_group->group_id]->from = strval($v[0]);
										$filter_tags['tags'][$tag_group->group_id]->to = strval($v[1]);
									}
								}
								else
									$filter_tags['tags'][$tag_group->group_id] = (array) $this->params_arr[$tag_group->name_translit];
								$show_subcategories = false;
						}
					}
					
					if ($this->settings->catalog_show_all_products && !empty($filter_tags['tags']))
					{
						$nalichie_group = $this->tags->get_taggroup('Есть в наличии');
						$in_stock = $this->tags->get_tags(array('group_id' => $nalichie_group->id, 'name'=>'да', 'enabled'=>1));
						$in_order = $this->tags->get_tags(array('group_id' => $nalichie_group->id, 'name'=>'под заказ', 'enabled'=>1));
						if (!empty($in_stock) || !empty($in_order))
						{
							$filter_tags['tags'][$nalichie_group->id] = array();
							
							if (!empty($in_stock))
								$filter_tags['tags'][$nalichie_group->id][] = $in_stock[0]->id;
								
							if (!empty($in_order))
								$filter_tags['tags'][$nalichie_group->id][] = $in_order[0]->id;
						}
					}
						
					foreach($tags_groups as $index=>$tag_group)
					{
						$group_filter_tags = $filter_tags;
						switch($tag_group->sort_type)
						{
							case 'name_asc':
								$sort = 'name';
								$sort_type = 'asc';
								break;
							case 'name_desc':
								$sort = 'name';
								$sort_type = 'desc';
								break;
							case 'numeric_asc':
								$sort = 'numeric';
								$sort_type = 'asc';
								break;
							case 'numeric_desc':
								$sort = 'numeric';
								$sort_type = 'asc';
								break;
							case 'position':
								$sort = 'position';
								$sort_type = 'asc';
								break;
							case 'popular':
								$sort = 'position';
								$sort_type = 'asc';
								break;
							default:
								$sort = 'position';
								$sort_type = 'asc';
								break;
						}
						$group_filter_tags['sort'] = $sort;
						$group_filter_tags['sort_type'] = $sort_type;
						$group_filter_tags['group_id'] = $tag_group->group_id;
						if (array_key_exists('tags', $group_filter_tags) && array_key_exists($tag_group->group_id, $group_filter_tags['tags']))
							unset($group_filter_tags['tags'][$tag_group->group_id]);
						$group_filter_tags['products_visible'] = 1;
						if ($this->settings->catalog_show_all_products)
							$group_filter_tags['products_in_stock'] = 1;
					
						if ($tag_group->mode == "range")
						{
							//$group_filter_tags['show_query'] = true;
							$tags_groups[$index]->min_value_available = $this->tags->get_tags_min_value($group_filter_tags);
							//unset($group_filter_tags['show_query']);
							
							$tags_groups[$index]->max_value_available = $this->tags->get_tags_max_value($group_filter_tags);
							
							$tags_groups[$index]->min_value = $this->tags->get_tags_min_value(array('enabled'=>1, 'brand_id'=>$brand->id, 'group_id'=>$tag_group->group_id));
							
							$tags_groups[$index]->max_value = $this->tags->get_tags_max_value(array('enabled'=>1, 'brand_id'=>$brand->id, 'group_id'=>$tag_group->group_id));
							
							//Приведение к шагу
							$tags_groups[$index]->min_value = floor($tags_groups[$index]->min_value / $tags_groups[$index]->diapason_step) * $tags_groups[$index]->diapason_step;
							$tags_groups[$index]->max_value = ceil($tags_groups[$index]->max_value / $tags_groups[$index]->diapason_step) * $tags_groups[$index]->diapason_step;
						}
						elseif($tag_group->mode == "logical")
						{
							$available = $this->tags->get_tags($group_filter_tags);
							$tags_groups[$index]->tags_available = array();
							foreach($available as $a)
								$tags_groups[$index]->tags_available[] = $a->id;
							$tags_groups[$index]->tags_all = $this->tags->get_tags(array('enabled'=>1, 'group_id'=>$tag_group->group_id, 'sort' => $sort, 'sort_type' => $sort_type));
							
							$tags_groups[$index]->tags_popular = array();
							foreach($tags_groups[$index]->tags_all as $tp)
								if ($tp->is_popular)
									$tags_groups[$index]->tags_popular[] = $tp;
						}
						else
						{
							$available = $this->tags->get_tags($group_filter_tags);
							$tags_groups[$index]->tags_available = array();
							foreach($available as $a)
								$tags_groups[$index]->tags_available[] = $a->id;
							
							$all_tags_filter = array('enabled'=>1, 'group_id'=>$tag_group->group_id, 'sort'=>$sort, 'sort_type'=>$sort_type, 'products_visible' => 1, 'brand_id' => $brand->id);
							if ($this->settings->catalog_show_all_products)
								$all_tags_filter['products_in_stock'] = 1;
							$tags_groups[$index]->tags_all = $this->tags->get_tags($all_tags_filter);
							
							$tags_groups[$index]->tags_all_arr = array();
							$tags_groups[$index]->tags_popular_arr = array();
							$tags_groups[$index]->tags_popular = array();
							foreach($tags_groups[$index]->tags_all as $p)
							{
								$tags_groups[$index]->tags_all_arr[] = $p->id;
								if ($p->is_popular)
								{
									$tags_groups[$index]->tags_popular_arr[] = $p->id;
									$tags_groups[$index]->tags_popular[] = $p;
								}
							}
						}
					}
					$this->design->assign('filter_tags_groups', $tags_groups);
					if (array_key_exists('tags', $filter_tags))
					{
						$this->design->assign('filter_tags', $filter_tags['tags']);
						$filter['tags'] = $filter_tags['tags'];
					}
				}
			}
		}
		
		$products_count = $this->products->count_products($filter);
		
		// Постраничная навигация
		if (array_key_exists('page', $this->params_arr) && $this->params_arr['page'] == 'all')
			$items_per_page = $products_count;
		else
			$items_per_page = $this->settings->products_num;
			
		$filter['page'] = $current_page;
		$filter['limit'] = $items_per_page;

		$products = $this->products->get_products($filter);
		
		$products = $this->products->get_data_for_frontend_products($products);
		
		/*foreach($products as $index=>$product)
		{
			$products[$index]->images = $this->image->get_images('products', $product->id);
			$products[$index]->image = reset($products[$index]->images);
			$variants_filter = array('product_id'=>$product->id, 'visible'=>1);
			if ($this->settings->catalog_default_variants_sort == "stock")
				$variants_filter['sort'] = $this->db->placehold('abs(IFNULL(v.stock, ?)) desc, stock desc', $this->settings->max_order_amount);
			$products[$index]->variants = $this->variants->get_variants($variants_filter);
			$products[$index]->variant = reset($products[$index]->variants);
			$products[$index]->badges = $this->badges->get_product_badges($product->id);
			$products[$index]->rating = $this->ratings->calc_product_rating($product->id);
			
			// Свойства товара
			$products[$index]->tags = $this->tags->get_product_tags($product->id);
			$products[$index]->tags_groups = array();
			foreach($products[$index]->tags as $tag)
			{
				if (!array_key_exists($tag->group_id, $products[$index]->tags_groups))
					$products[$index]->tags_groups[$tag->group_id] = array();
				$products[$index]->tags_groups[$tag->group_id][] = $tag;
			}
			
			$products[$index]->reviews_count = $this->reviews->count_reviews(array('product_id'=>$product->id, 'visible'=>1, 'moderated'=>1));
		}*/
		
		$tags_groups = $this->tags->get_taggroups(array('is_auto'=>0, 'enabled'=>1));
		$this->design->assign('tags_groups', $tags_groups);
		
		$this->design->assign('params_arr', $this->params_arr);
		$this->design->assign('products_count', $products_count);
		$pages_num = ceil($products_count/$items_per_page);
		$this->design->assign('total_pages_num', $pages_num);

		$this->design->assign('data_type', 'brand');
		$this->design->assign('products', $products);
		
		$filter['limit'] = 10000;
		unset($filter['tags']);
		$products_temp = $this->products->get_products($filter);
		
		//$finded_categories[0] = array('id'=>0, 'url'=>'','name'=>'Все категории','position'=>0,'count'=>$products_count,'children'=>array());
		$finded_categories = array();
		
		$products_module = $this->furl->get_module_by_name('ProductsController');
		$brand_tag_id = 0;
		$categories_with_filter_arr = array();
		$this->db->query("SELECT * FROM __tags_groups WHERE name=? AND is_auto=?", "Бренд", 1);
		$brand_group = $this->db->result();
		if (!empty($brand_group))
		{
			$this->db->query("SELECT * FROM __tags WHERE group_id=? AND name=?", $brand_group->id, $brand->name);
			$brand_tag_id = $this->db->result('id');
			
			$this->db->query("SELECT distinct c.id FROM __categories c
				INNER JOIN __tags_sets ts ON c.set_id=ts.id
				INNER JOIN __tags_sets_tags tst ON ts.id=tst.set_id
				WHERE tst.tag_id=?", $brand_group->id);
			$categories_with_filter_arr = $this->db->results('id');
		}
		
		foreach($products_temp as $index=>&$product)
		{
			$product->categories = $this->categories->get_product_categories($product->id);
			if (!$product->categories)
				continue;
			foreach($product->categories as $cat)
			{
				$cat_tmp = $this->categories->get_category($cat->category_id);
				while($cat_tmp->parent_id > 0 && empty($cat_tmp->set_id))
				{
					$cat_tmp = $this->categories->get_category($cat_tmp->parent_id);
					if (empty($cat_tmp))
						break;
				}
				if (empty($cat_tmp) || empty($cat_tmp->set_id))
					continue;
				
				$irsc_arr = array_intersect($cat_tmp->children, $categories_with_filter_arr);
				if (!array_key_exists($cat_tmp->id, $finded_categories) && !empty($irsc_arr))
					$finded_categories[$cat_tmp->id] = array('id'=>$cat_tmp->id,'url'=>$this->config->root_url . $products_module->url . $cat_tmp->url . $this->settings->postfix_category_url . '?' . $brand_group->name_translit . '=' . $brand_tag_id,'name'=>$cat_tmp->name,'position'=>$cat_tmp->position,'count'=>0,'children'=>$cat_tmp->children);
			}
		}
		
		foreach($products_temp as $index=>&$product)
		{
			if (!$product->categories)
				continue;
			foreach($product->categories as $cat)
			{
				foreach($finded_categories as &$fc)
					if (in_array($cat->category_id, $fc['children']))
						$fc['count'] += 1;
			}
		}
		//удалим массив подкатегорий, чтобы уменьшить трафик
		foreach($finded_categories as &$fc)
			unset($fc['children']);
		$finded_categories_result = array();
		foreach($finded_categories as $cat_id=>$cat)
		{
			if (!array_key_exists($cat['position'], $finded_categories_result))
				$finded_categories_result[$cat['position']] = array();
			$finded_categories_result[$cat['position']][] = $cat;
		}
		$this->design->assign('finded_categories', $finded_categories_result);
		
		if ($brand->is_auto_metatags)
		{
			$meta_title = $this->settings->seo_brand_title;
			$meta_keywords = $this->settings->seo_brand_keywords;
			$meta_description = $this->settings->seo_brand_description;
			
			$meta_title = str_replace('{brand_name}', !empty($brand->frontend_name) ? $brand->frontend_name : $brand->name, $meta_title);
			$meta_title = str_replace('{brand_title}', $brand->meta_title, $meta_title);
			$meta_title = str_replace('{brand_keywords}', $brand->meta_keywords, $meta_title);
			$meta_title = str_replace('{brand_description}', $brand->meta_description, $meta_title);
			
			$meta_keywords = str_replace('{brand_name}', !empty($brand->frontend_name) ? $brand->frontend_name : $brand->name, $meta_keywords);
			$meta_keywords = str_replace('{brand_title}', $brand->meta_title, $meta_keywords);
			$meta_keywords = str_replace('{brand_keywords}', $brand->meta_keywords, $meta_keywords);
			$meta_keywords = str_replace('{brand_description}', $brand->meta_description, $meta_keywords);
			
			$meta_description = str_replace('{brand_name}', !empty($brand->frontend_name) ? $brand->frontend_name : $brand->name, $meta_description);
			$meta_description = str_replace('{brand_title}', $brand->meta_title, $meta_description);
			$meta_description = str_replace('{brand_keywords}', $brand->meta_keywords, $meta_description);
			$meta_description = str_replace('{brand_description}', $brand->meta_description, $meta_description);
		}
		else
		{
			$meta_title = $brand->meta_title;
			$meta_keywords = $brand->meta_keywords;
			$meta_description = $brand->meta_description;
		}
		
		if ($current_page > 1)
			$meta_title .= ' - Страница '.$current_page;
		
		if ($ajax)
		{
			$data = array(
				'success' => true, 
				'body_brand_css' => $brand->css_class, 
				'brand_id' => $brand_id, 
				'meta_title' => $meta_title, 
				'meta_description' => $meta_description, 
				'meta_keywords' => $meta_keywords, 
				'data' => $this->design->fetch($this->design->getTemplateDir('frontend').'brand.tpl'),
				'filter' => $this->design->fetch($this->design->getTemplateDir('frontend').'filter.tpl'),
				'finded_categories' => $this->design->fetch($this->design->getTemplateDir('frontend').'index-finded-categories.tpl'));
			
			header("Content-type: application/json; charset=UTF-8");
			header("Cache-Control: must-revalidate");
			header("Pragma: no-cache");
			header("Expires: -1");
			print json_encode($data);
			die();
		}
	
		$this->design->assign('meta_title', $meta_title);
		$this->design->assign('meta_description', $meta_description);
		$this->design->assign('meta_keywords', $meta_keywords);

		return $this->design->fetch($this->design->getTemplateDir('frontend').'brand.tpl');
	}
}
