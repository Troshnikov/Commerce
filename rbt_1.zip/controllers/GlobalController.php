<?PHP

/*
 * Базовый класс для всех Controllers
 */

require_once('api/core/Commerce.php');

class GlobalController extends Commerce
{
	/* Смысл класса в доступности следующих переменных в любом View */
	public $main_currency;
	public $admin_currency;
	public $all_currencies;
	public $user;
	public $group;
	public $page;
	public $global_group_permissions;
	
	/* Класс View похож на синглтон, храним статически его инстанс */
	private static $controller_instance;
	
	public function __construct()
	{
		parent::__construct();
		
		// Если инстанс класса уже существует - просто используем уже существующие переменные
		if(self::$controller_instance)
		{
			$this->main_currency     = &self::$controller_instance->main_currency;
			$this->admin_currency     = &self::$controller_instance->admin_currency;
			$this->all_currencies   = &self::$controller_instance->all_currencies;
			$this->user         = &self::$controller_instance->user;
			$this->group        = &self::$controller_instance->group;	
			$this->page         = &self::$controller_instance->page;	
			$this->global_group_permissions = &self::$controller_instance->global_group_permissions;
		}
		else
		{
			// Сохраняем свой инстанс в статической переменной,
			// чтобы в следующий раз использовать его
			self::$controller_instance = $this;
			
			// Все валюты
			$this->all_currencies = $this->currencies->get_currencies(array('enabled'=>1));
			$this->db->query("SELECT * FROM __currencies WHERE enabled = 1 AND use_main = 1");
			$this->main_currency = $this->db->result();
			$this->db->query("SELECT * FROM __currencies WHERE enabled = 1 AND use_admin = 1");
			$this->admin_currency = $this->db->result();
	
			// Пользователь, если залогинен
			if(isset($_SESSION['user_id']))
			{
				$u = $this->users->get_user(intval($_SESSION['user_id']));
				if($u && $u->enabled)
				{
					//echo "user_name=".$u->name."<br>";
					$this->user = $u;
					$this->group = $this->users->get_group($this->user->group_id);

					$query = $this->db->placehold("SELECT am.name FROM __access_modules am INNER JOIN __access_permissions ap ON am.id=ap.module_id WHERE am.section=? AND ap.group_id=?", 'admin', $this->group->id);
					$this->db->query($query);
					$this->global_group_permissions = $this->db->results('name');
					if (empty($this->global_group_permissions))
						$this->global_group_permissions = array('LoginControllerAdmin');
				}
				else
					$this->global_group_permissions = array('LoginControllerAdmin');
			}
			else
				$this->global_group_permissions = array('LoginControllerAdmin');
			$this->design->assign('global_group_permissions', $this->global_group_permissions);


			$this->design->assign('currencies',	$this->all_currencies);
			$this->design->assign('main_currency',	$this->main_currency);
			$this->design->assign('admin_currency',	$this->admin_currency);
			if (!empty($this->user))
			{
				$this->design->assign('user',       $this->user);
				$this->design->assign('group',      $this->group);
			}
			
			$this->design->assign('global_group_permissions', $this->global_group_permissions);
			$this->design->assign('config',		$this->config);
			$this->design->assign('settings',	$this->settings);
			$this->design->assign('banners',	$this->banners);
		}
	}

	
		
	/**
	 *
	 * Отображение
	 *
	 */
	function fetch()
	{
		return false;
	}
}