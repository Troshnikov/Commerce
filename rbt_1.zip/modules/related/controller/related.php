<?php

require_once('api/core/Commerce.php');

class RelatedControllerAdmin extends Commerce {

	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null){
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}
		
	function fetch() {
		if (!(isset($_SESSION['admin']) && $_SESSION['admin']=='admin'))
			header("Location: http://".$_SERVER['SERVER_NAME']."/rbt/");
		
		$mode = '';
		
		foreach($this->params_arr as $p=>$v)
		{
			switch ($p)
			{
				case "mode":
					$mode = $v;
					break;
			}
		}
		
		if ($this->request->method('post')){
			
			$related = new stdClass;
			$related->id = $this->request->post('id', 'integer');
			$related->type_id = $this->request->post('type_id', 'integer');
			
			$post_related_types = (array) $this->request->post('related_type');
			$post_products_count = (array) $this->request->post('products_count');
			$post_conditions = (array) $this->request->post('condition');
			$post_valueRanges = (array) $this->request->post('valueRange');
			
			$related_types = array();
			foreach($post_related_types as $index => $prt)
			{
				$r = new stdClass;
				$r->type_id = $related->type_id;
				$r->related_type_id = $prt;
				$r->products_count = intval($post_products_count[$index]);
				
				$conditions = array();
				if (!empty($post_conditions[$index]))
					foreach($post_conditions[$index] as $n => $c)
					{
						$tmpa = array('property_id' => $n, 'condition' => $c, 'value' => '');
						if ($c == 2)
							$tmpa['value'] = $post_valueRanges[$index][$n];
						$conditions[] = $tmpa;
					}
				$r->conditions = json_encode($conditions);
				
				$related_types[] = $r;
			}			
			
			/*$related_types = (array) $this->request->post('related_type');
			foreach($related_types as $idx=>$rt)
				if (empty($rt))
					unset($related_types[$idx]);
			$related->related_types = join(',', $related_types);
			
			
			$conditions = array();
			
			if ($this->request->post('condition'))
				foreach($this->request->post('condition') as $n=>$c)
				{
					$tmpa = array('property_id' => $n, 'condition' => $c, 'value' => '');
					if ($c == 2)
						$tmpa['value'] = $valueRanges[$n];
					$conditions[] = $tmpa;
				}
			
			$related->conditions = json_encode($conditions);*/
			
			if (empty($related->id))
			{
				$this->db->query("INSERT INTO __external_table_related SET ?%", (array) $related);
				$related->id = $this->db->insert_id();
			}
			else
				$this->db->query("UPDATE __external_table_related SET ?% WHERE id=? LIMIT 1", (array) $related, intval($related->id));
			
			$this->db->query("DELETE FROM __external_table_related_types WHERE type_id=?", $related->type_id);
			
			if (!empty($related_types))
				foreach($related_types as $rt)
					$this->db->query("INSERT INTO __external_table_related_types SET ?%", (array) $rt);
			
			$close_after_save = $this->request->post('close_after_save', 'integer');
			$add_after_save = $this->request->post('add_after_save', 'integer');
			
			$mode = 'edit-type';
			if ($close_after_save)
				$mode = '';
			else
				if ($add_after_save)
					$mode = 'add-type';
				else
					$this->params_arr['id'] = $related->id;
		}
		
		switch($mode)
		{
			case "edit-type":
				$id = intval($this->params_arr['id']);
				$this->db->query("SELECT tr.* FROM __external_table_related tr WHERE id=?", $id);
				$related = $this->db->result();
				if (!empty($related))
				{
					$this->db->query("SELECT * FROM __external_table_related_types WHERE type_id=? ORDER BY id", $related->type_id);
					$related->related_types = $this->db->results();
					
					if (!empty($related->related_types))
						foreach($related->related_types as $idx=>$rt)
						{
							$related->related_types[$idx]->conditions = (array) json_decode($rt->conditions);
							if (!empty($related->related_types[$idx]->conditions))
							{
								foreach($related->related_types[$idx]->conditions as $index=>$c)
									$related->related_types[$idx]->conditions[$index]->property = $this->tags->get_taggroup($c->property_id);
							}
						}
						
					/*$related->type = $this->products_types->get_type($related->type_id);
					if (!empty($related->related_types))
						$related->related_types = explode(',', $related->related_types);
					
					$conditions = (array) json_decode($related->conditions);
					if (!empty($conditions))
					{
						foreach($conditions as $index=>$c)
							$conditions[$index]->property = $this->tags->get_taggroup($c->property_id);
						$this->design->assign('conditions', $conditions);
					}*/
				}
				$this->design->assign('related', $related);
				break;
			case "delete-type":
				$id = intval($this->params_arr['id']);
				if (!empty($id))
					$this->db->query("DELETE FROM __external_table_related WHERE id=?", $id);
			case "":
				$this->db->query("SELECT tr.* FROM mc_external_table_related tr INNER JOIN __products_types pt ON tr.type_id=pt.id ORDER BY pt.position");
				$related = $this->db->results();
				foreach($related as $idx=>$r)
				{
					$related[$idx]->type = $this->products_types->get_type($r->type_id);
					/*$related[$idx]->related_types = array();
					if (!empty($r->related_types))
						foreach(explode(',', $r->related_types) as $rr)
							$related[$idx]->related_types[] = $this->products_types->get_type($rr);*/
				}
				$this->design->assign('related', $related);
				break;
		}
		
		$this->design->assign('types', $this->products_types->get_types(array('sort' => 'name')));
		$this->design->assign('tags_groups', $this->tags->get_taggroups(array('sort' => 'name')));
		
		$this->db->query("SELECT type_id FROM __external_table_related");
		$this->design->assign('exist_types', $this->db->results('type_id'));
		
		if ($mode == 'add-type' || $mode == 'edit-type')
			return $this->design->fetch('modules/related/template/related-add.tpl');
		else
			return $this->design->fetch('modules/related/template/related.tpl');
	}
}
