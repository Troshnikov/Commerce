<?php

require_once('api/core/Commerce.php');

class RelatedFrontendController extends Commerce {

	private $param_url, $params_arr, $options;
	
	public function set_params($url = null, $options = null){
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}
	
	function get_related($data) {
		$product = $data['product'];
		$tags = $data['tags'];
		
		if (empty($product) || empty($tags) || empty($product->type_id))
			return '';
		
		$this->db->query("SELECT * FROM __external_table_related WHERE type_id=?", $product->type_id);
		$related = $this->db->result();
		
		if (empty($related))
			return '';
		
		$this->db->query("SELECT * FROM __external_table_related_types WHERE type_id=? ORDER BY id", $related->type_id);
		$related_types = $this->db->results();
		
		if (empty($related_types))
			return '';
		
		$tmp_auto_products = array();
		
		foreach($related_types as $rt)
		{
			$filter = array();
			$filter['visible'] = 1;
			$filter['limit'] = 1000;
			if ($this->settings->catalog_show_all_products)
				$filter['in_stock'] = 1;
			$filter['type_id'] = $rt->related_type_id;
			
			$conditions = (array) json_decode($rt->conditions);
			
			$filter_tags = array();
			if (!empty($conditions))
				foreach($conditions as $c)
				{
					if (!array_key_exists($c->property_id, $tags))
						continue;
					
					if ($c->condition == 1)
					{
						$filter_tags[$c->property_id] = array();
						foreach($tags[$c->property_id] as $t)
							$filter_tags[$c->property_id][] = $t->id;
					}
					else
					{
						$stdc = new stdClass;
						$t = reset($tags[$c->property_id]);
						$stdc->from = floatval($t->name) - floatval($c->value);
						$stdc->to = floatval($t->name) + floatval($c->value);
						$filter_tags[$c->property_id] = $stdc;
					}
				}
			$filter['tags'] = $filter_tags;
			
			$products = $this->products->get_products($filter);
			
			if (empty($products))
				continue;
			
			if (count($products) <= $rt->products_count)
			{
				foreach($products as $p)
					$tmp_auto_products[] = $p;
			}
			else
			{
				$keys = array_rand($products, $rt->products_count);
				$auto_products = array();
				foreach($keys as $k)
					$tmp_auto_products[] = $products[$k];
			}
				
			/*if (!empty($products))
				foreach($products as $p)
					$tmp_auto_products[] = $p;*/
		}
		
		/*$types_ids = explode(',', $related->related_types);
		$conditions = (array) json_decode($related->conditions);
		
		$filter_tags = array();
		foreach($conditions as $c)
		{
			if (!array_key_exists($c->property_id, $tags))
				continue;
			
			if ($c->condition == 1)
			{
				$filter_tags[$c->property_id] = array();
				foreach($tags[$c->property_id] as $t)
					$filter_tags[$c->property_id][] = $t->id;
			}
			else
			{
				$stdc = new stdClass;
				$t = reset($tags[$c->property_id]);
				$stdc->from = floatval($t->name) - floatval($c->value);
				$stdc->to = floatval($t->name) + floatval($c->value);
				$filter_tags[$c->property_id] = $stdc;
			}
		}
		
		$filter = array();
		$filter['visible'] = 1;
		$filter['limit'] = 10000;
		if ($this->settings->catalog_show_all_products)
			$filter['in_stock'] = 1;
		$filter['tags'] = $filter_tags;
		if (!empty($types_ids))
			$filter['type_id'] = $types_ids;
		
		$tmp_auto_products = $this->products->get_products($filter);*/
		
		/*if (count($tmp_auto_products) <= $related->products_count)
			$auto_products = $tmp_auto_products;
		else
		{
			$keys = array_rand($tmp_auto_products, $related->products_count);
			$auto_products = array();
			foreach($keys as $k)
				$auto_products[] = $tmp_auto_products[$k];
		}*/
		
		$auto_products = $tmp_auto_products;
		unset($tmp_auto_products);
		
		$auto_products = $this->products->get_data_for_frontend_products($auto_products);
		$this->design->assign('auto_products', $auto_products);
		
		$products_types_ids = array();
		foreach($auto_products as $rp)
			if (!empty($rp->type_id) && !in_array($rp->type_id, $products_types_ids))
				$products_types_ids[] = $rp->type_id;
			
		if (!empty($products_types_ids))
		{
			$external_related_products_types = $this->products_types->get_types(array('id' => $products_types_ids, 'visible' => 1));
			$this->design->assign('external_related_products_types', $external_related_products_types);
		}
		
		/*������� ������ ������ �� ���������*/
		$this->design->assign('mode', $this->settings->default_related_products_mode);
		
		return $this->design->fetch('modules/related/template/related-frontend.tpl');
	}
}