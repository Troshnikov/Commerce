<?php

require_once('api/core/Commerce.php');

class YandexSmtpControllerAdmin extends Commerce {

	private $param_url, $params_arr, $options;

	public function set_params($url = null, $options = null){
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}
		
	function fetch() {
		if (!(isset($_SESSION['admin']) && $_SESSION['admin']=='admin'))
			header("Location: http://".$_SERVER['SERVER_NAME']."/rbt/");
		
		if ($this->request->method('post')){
			$this->settings->yandexsmtp_enabled = $this->request->post('yandexsmtp_enabled', 'boolean');
			$this->settings->yandexsmtp_login = $this->request->post('yandexsmtp_login');
			$this->settings->yandexsmtp_password = $this->request->post('yandexsmtp_password');
		}

		return $this->design->fetch('modules/yandex-smtp/template/yandex-smtp.tpl');
	}
}
