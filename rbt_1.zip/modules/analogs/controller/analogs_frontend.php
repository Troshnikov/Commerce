<?php

require_once('api/core/Commerce.php');

class AnalogsFrontendController extends Commerce {

	private $param_url, $params_arr, $options;
	
	public function set_params($url = null, $options = null){
		$this->options = $options;
		
		$url = urldecode(trim($url, '/'));
		$delim_pos = mb_strpos($url, '?', 0, 'utf-8');
		
		if ($delim_pos === false)
		{
			$this->param_url = $url;
			$this->params_arr = array();
		}
		else
		{
			$this->param_url = trim(mb_substr($url, 0, $delim_pos, 'utf-8'), '/');
			$url = mb_substr($url, $delim_pos+1, mb_strlen($url, 'utf-8')-($delim_pos+1), 'utf-8');
			$this->params_arr = array();
			foreach(explode("&", $url) as $p)
			{
				$x = explode("=", $p);
				$this->params_arr[$x[0]] = "";
				if (count($x)>1)
					$this->params_arr[$x[0]] = $x[1];
			}
		}
	}
	
	function get_analogs($data) {
		$conditions = (array) json_decode($this->settings->analogs_conditions);
		
		$product = $data['product'];
		$tags = $data['tags'];
		
		$filter_tags = array();
		foreach($conditions as $c)
		{
			if (!array_key_exists($c->property_id, $tags))
				continue;
			
			if ($c->condition == 1)
			{
				$filter_tags[$c->property_id] = array();
				foreach($tags[$c->property_id] as $t)
					$filter_tags[$c->property_id][] = $t->id;
			}
			else
			{
				$stdc = new stdClass;
				$t = reset($tags[$c->property_id]);
				$stdc->from = floatval($t->name) - floatval($c->value);
				$stdc->to = floatval($t->name) + floatval($c->value);
				$filter_tags[$c->property_id] = $stdc;
			}
		}
		
		$filter = array();
		$filter['visible'] = 1;
		$filter['limit'] = 10000;
		if ($this->settings->catalog_show_all_products)
			$filter['in_stock'] = 1;
		$filter['tags'] = $filter_tags;
		
		$tmp_auto_products = $this->products->get_products($filter);
		
		$auto_products = array();
		if (count($tmp_auto_products) <= $this->settings->analogs_products_count)
			$auto_products = $tmp_auto_products;
		elseif(!empty($this->settings->analogs_products_count))
		{
			$keys = array_rand($tmp_auto_products, $this->settings->analogs_products_count);
			$auto_products = array();
			foreach($keys as $k)
				$auto_products[] = $tmp_auto_products[$k];
		}
		$auto_products = $this->products->get_data_for_frontend_products($auto_products);
		$this->design->assign('auto_products', $auto_products);
		
		$products_types_ids = array();
		foreach($auto_products as $rp)
			if (!empty($rp->type_id) && !in_array($rp->type_id, $products_types_ids))
				$products_types_ids[] = $rp->type_id;
		if (!empty($products_types_ids))
		{
			$external_analogs_products_types = $this->products_types->get_types(array('id' => $products_types_ids, 'visible' => 1));
			$this->design->assign('external_analogs_products_types', $external_analogs_products_types);
		}
		
		/*������� ������ ������ �� ���������*/
		$this->design->assign('mode', $this->settings->default_related_products_mode);
		
		return $this->design->fetch('modules/analogs/template/analogs-frontend.tpl');
	}
}