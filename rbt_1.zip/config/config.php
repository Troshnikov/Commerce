;<? exit(); ?>

[database]

;Сервер базы данных
db_server = "localhost"
;Пользователь базы данных
db_user = "root"
;Пароль к базе
db_password = ""
;Имя базы
db_name = "service_rbt"
;Префикс для таблиц
db_prefix = rbt_;
;Кодировка базы данных
db_charset = UTF8;

;Режим SQL
db_sql_mode =;

[php]
error_reporting = E_ALL;
php_charset = UTF8;
php_locale_collate = ru_RU;
php_locale_ctype = ru_RU;
php_locale_monetary = ru_RU;
php_locale_numeric = ru_RU;
php_locale_time = ru_RU;

logfile = admin/log/log.txt;

[smarty]

smarty_compile_check = true;
smarty_caching = false;
smarty_cache_lifetime = 0;
smarty_debugging = false;
 
[images]

;Директория оригиналов изображений
original_images_dir = files/images/originals/;
original_tempimages_dir = files/images/temp_originals/;

;Директория миниатюр
resized_images_dir = files/images/resized/;
resized_tempimages_dir = files/images/temp_resized/;

;Файл изображения с водяным знаком
watermark_file = files/watermark/watermark.png;

[files]

;Директория аттачментов
attachments_dir = files/attachments/;

;Директория хранения цифровых товаров
downloads_dir = files/downloads/;

[dirs]
;Путь к админке
admin_url = rbt/;